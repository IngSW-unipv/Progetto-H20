package com.example.email;

public class MyConstants {
	
	// Replace with your email here:  
    public static final String MY_EMAIL = "carpoolingunipv@gmail.com";
 
    // Replace password!!
    public static final String MY_PASSWORD = "lucavaghi96";
 
    // And receiver!
    public static String FRIEND_EMAIL = "";
}
