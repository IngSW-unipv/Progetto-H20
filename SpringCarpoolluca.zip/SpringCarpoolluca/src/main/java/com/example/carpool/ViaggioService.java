package com.example.carpool;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ViaggioService implements iViaggioService {
	
	@Autowired
    private ViaggioRepository repository;

    @Override
    public List<Viaggio> findAll() {
        return (List<Viaggio>) repository.findAll();
    }
    
    

}
