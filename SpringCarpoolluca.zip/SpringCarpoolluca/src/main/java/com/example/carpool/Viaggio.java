package com.example.carpool;

import java.awt.geom.Point2D;
import java.util.Date;

import javax.persistence.*;

@Entity // This tells Hibernate to make a table out of this class
@Table(name = "viaggio")
public class Viaggio {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) //Controllare nel database se è effettivamente impostato AI
	private long viaggioId;
	@Column(nullable = false, unique = false, length = 45)
	private long userId;
	@Column(nullable = false, unique = false, length = 45)
	private String partenza;
	@Column(nullable = false, unique = false, length = 45)
	private double partenzaX;
	@Column(nullable = false, unique = false, length = 45)
	private double partenzaY;
	@Column(nullable = false, unique = false, length = 45)
	private String destinazione;
	@Column(nullable = false, unique = false, length = 45)
	private double destinazioneX;
	@Column(nullable = false, unique = false, length = 45)
	private double destinazioneY;
	@Column(nullable = false, unique = false, length = 5)
	private int postiTotali;
	@Column(nullable = false, unique = false, length = 5)
	private int postiPrenotati;
	@Column(nullable = false, unique = false, length = 5)
	private double prezzo;
	@Temporal(TemporalType.TIMESTAMP)
	private Date creationDate;
	private Date viaggioDate;
	
	/*@OneToMany(mappedBy = "Viaggio")
	private Set<User> users;*/
	
	//La tag Transient permette di aggiungere un attributo che non fa parte del DB
	@Transient
	private double distanza;
	
	/*
	 * Point2D è un tipo che contiene 2 valori Double, comodo, teniamolo per esempio
	 * 
	@Transient
	private Point2D puntoPartenza = new Point2D.Double(partenzaX, partenzaY);
	@Transient
	private Point2D puntoDestinazione = new Point2D.Double(destinazioneX, destinazioneY);
	*/
	
	//Il costruttore non serve per mettere il viaggio nel DB, però viene usato per altre cose
	public Viaggio (String partenza, double partenzaX, double partenzaY, String destinazione, double destinazioneX, double destinazioneY, int postiTotali) {
		
		this.partenza = partenza;
		this.partenzaX = partenzaX;
		this.partenzaX = partenzaY;
		this.destinazione = destinazione;
		this.destinazioneX = destinazioneX;
		this.destinazioneY = destinazioneY;
		this.postiTotali = postiTotali;
	}
	
	public Viaggio() {
	}

	public long getViaggioId() {
		return viaggioId;
		}
	public void setViaggioId(long viaggioId) {
		this.viaggioId = viaggioId;
		} 
	public String getPartenza() {
		return partenza;
		}
	public void setPartenza(String partenza) {
		this.partenza = partenza;
		}
	public double getPartenzaX() {
		return partenzaX;
		}
	public void setPartenzaX(double partenzaX) {
		this.partenzaX = partenzaX;
		}
	public double getPartenzaY() {
		return partenzaY;
		}
	public void setPartenzaY(double partenzaY) {
		this.partenzaY = partenzaY;
		}
	public String getDestinazione() {
		return destinazione;
		}
	public void setDestinazione(String destinazione) {
		this.destinazione = destinazione;
		}
	public double getDestinazioneX() {
		return destinazioneX;
		}
	public void setDestinazioneX(double destinazioneX) {
		this.destinazioneX = destinazioneX;
		}
	public double getDestinazioneY() {
		return destinazioneY;
		}
	public void setDestinazioneY(double destinazioneY) {
		this.destinazioneY = destinazioneY;
		}
	public Date getcreationDate() {
		return creationDate;
		}
	public void setcreationDate(Date creationDate) {
		this.creationDate = creationDate;
		}

	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}

	public int getPostiTotali() {
		return postiTotali;
	}
	public void setPostiTotali(int postiTotali) {
		this.postiTotali = postiTotali;
	}

	public int getPostiPrenotati() {
		return postiPrenotati;
	}
	public void setPostiPrenotati(int postiPrenotati) {
		this.postiPrenotati = postiPrenotati;
	}

	public double getDistanza() {
		return distanza;
	}
	public void setDistanza(double distanza) {
		this.distanza = distanza;
	}

	public Date getViaggioDate() {
		return viaggioDate;
	}
	public void setViaggioDate(Date viaggioDate) {
		this.viaggioDate = viaggioDate;
	}

	public double getPrezzo() {
		return prezzo;
	}

	public void setPrezzo(double prezzo) {
		this.prezzo = prezzo;
	}
	
	/*
	public Point2D getPuntoPartenza() {
		return puntoPartenza;
	}

	public void setPuntoPartenza(Point2D puntoPartenza) {
		this.puntoPartenza = puntoPartenza;
	}

	public Point2D getPuntoDestinazione() {
		return puntoDestinazione;
	}

	public void setPuntoDestinazione(Point2D puntoDestinazione) {
		this.puntoDestinazione = puntoDestinazione;
	}*/
	
}
