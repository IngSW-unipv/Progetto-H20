package com.example.carpool;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity // This tells Hibernate to make a table out of this class
@Table(name = "prenota")
public class Prenota {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long prenotaId;
	@Column(nullable = false, unique = false, length = 45)
	private long userId; 
	@Column(nullable = false, unique = false, length = 45)
	private long viaggioId;

	public long getPrenotaId() {
		return prenotaId;
	}
	public void setPrenotaId(long prenotaId) {
		this.prenotaId = prenotaId;
	}
	public long getViaggioId() {
		return viaggioId;
	}
	public void setViaggioId(long viaggioId) {
		this.viaggioId = viaggioId;
	}
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
}
