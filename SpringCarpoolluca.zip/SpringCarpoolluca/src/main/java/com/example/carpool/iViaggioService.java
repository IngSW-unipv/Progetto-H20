package com.example.carpool;

import java.util.List;

public interface iViaggioService {
	 List<Viaggio> findAll();
}
