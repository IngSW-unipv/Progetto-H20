package com.example.carpool;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface PrenotaRepository extends JpaRepository<Prenota, Long> {	
	@Query("SELECT u FROM Prenota u WHERE u.userId = ?1")
	public Prenota findByuserId(Long userId);
}