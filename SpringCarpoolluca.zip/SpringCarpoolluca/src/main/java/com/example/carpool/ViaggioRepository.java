package com.example.carpool;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface ViaggioRepository extends JpaRepository<Viaggio, Long> {
	
	@Query("SELECT u FROM Viaggio u WHERE u.viaggioId = ?1")
	public Viaggio findByviaggioId(Long viaggioId);
	
	@Modifying
    @Query(
      value = 
        "insert into prenotazioni (user_id, viaggio_id) values (:userId, :viaggioId)",
      nativeQuery = true)
    public void insertPrenotazione(@Param("userId") Long userId, @Param("viaggioId") Long viaggioId);
}
