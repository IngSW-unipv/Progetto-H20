package com.example.carpool;

import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import functions.Functions;


@Controller
public class Controllers {
	
	@Autowired
	private UserRepository userRepo;
	
	@Autowired
    private iViaggioService viaggioService;
	
	@Autowired
	private ViaggioRepository viaggioRepo;
	
	@Autowired 
	private PrenotaRepository prenotaRepo;
	
	//Ogni richiesta POST fa prima un GET, e questa richiesta GET finisce qua
	//Quindi è qua che bisogna creare gli oggetti user e coordinate per i relativi form se no non va
	@GetMapping("/")
	public String generalController(@ModelAttribute User user, @ModelAttribute Prenota prenota, @ModelAttribute Viaggio viaggio, Model model) {
		
		//Aggiungo gli oggetti user e coordinate per poter usare la registrazione, creazione viaggi, login...
		model.addAttribute("user", new User());
		model.addAttribute("viaggio", new Viaggio());
		model.addAttribute("prenota", new Prenota());
		
		//Curioso fenomeno, basta usare la variabile di tipo CoordinateRepository invece di new CoordinateService().findAll()
		//Anche se quel metodo findAll() comunque usa un CoordinateRepository, eppure restituisce null.
		//Questo pezzo è qua sotto a GetMapping"/" perchè è nella pagina index. 
		//Magari con javascript Ajax si può spostare in una richiesta POST a parte? 
		model.addAttribute("viaggi", viaggioRepo.findAll());
		
		
		var viaggioOrdered = (List<Viaggio>) viaggioRepo.findAll();
		Viaggio viaggiotest = new Viaggio ("partenzatest", 1.0, 0.1, "destinazionetest", 2.0, 0.2, 5);
		viaggioOrdered = Functions.setDistances(viaggioOrdered, viaggiotest);
		Collections.sort(viaggioOrdered, new Functions(viaggiotest, viaggioOrdered));
		for (Viaggio i : viaggioOrdered) {
			System.out.println("Partenza: " + i.getPartenza() + " Distanza dal viaggio di test: " + i.getDistanza());
		}
        model.addAttribute("viaggioOrdered", viaggioOrdered);
        
        var prenotazioni = (List<Prenota>) prenotaRepo.findAll();
        //Decisamente questa cosa va mandata via POST con javascript solo dopo che si è loggati
        /*List<Prenota> userPrenotazioni = new ArrayList<>();
        CustomUserDetails user1 = (CustomUserDetails) SecurityContextHolder.getContext()
	            .getAuthentication()
	            .getPrincipal();
        if (user1 != null) {
        	for (Prenota i : prenotazioni) {
        		if (i.getUserId() == user1.getId()) {
        			userPrenotazioni.add(i);
        			System.out.println("Prenotazione fatta da: " + i.getUserId() + " sul viaggio: " + i.getViaggioId());
        		}
        	}
        }*/
        model.addAttribute("prenotazioni", prenotazioni);
        
		return "index";
	}

	@PostMapping("/user_register")
	public String userRegister(User user, RedirectAttributes atts) {
	    BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
	    String encodedPassword = passwordEncoder.encode(user.getPassword());
	    user.setPassword(encodedPassword);
	    user.setEnabled(true);
	    User check = userRepo.findByEmail(user.getEmail());
	    if (check == null) {
	    	try {
	    		userRepo.save(user);
	    		System.out.println("Nuovo utente registrato! ");
	    		return "redirect:/";
	    		}
	    	catch (Exception e) {
	    		atts.addAttribute("hasErrors", true); //Al momento non usato...
	    		System.out.println("Eccezione! ");
	    		return "redirect:/";
	    		}
	    	}
	    else {
	    	System.out.println("Utente già esistente");
	    	return "redirect:/";
	    	}
	    }
	
	@PostMapping("/user_edit_FirstName")
	public String userEdit(String FirstName) {
		CustomUserDetails user1 = (CustomUserDetails) SecurityContextHolder.getContext()
	            .getAuthentication()
	            .getPrincipal();
		
		Long id = user1.getId();
		User user2 = userRepo.findById(id).orElseThrow(RuntimeException::new);; //L'eccezione serve perchè non è detto che lo trovi, altrimenti servirebbe Optional
		user2.setFirstName(FirstName);
	    userRepo.save(user2);
	    return "redirect:/";
	}
	
	@GetMapping("/viaggio_show_ordered")
	public String viaggio_show_ordered(Model model) {
		var viaggi = (List<Viaggio>) viaggioRepo.findAll();
		Viaggio viaggio = new Viaggio ("partenzatest", 1.0, 0.1, "destinazionetest", 2.0, 0.2, 5);
		//Functions funzioni = new Functions (viaggio, viaggi);
		viaggi = Functions.setDistances(viaggi, viaggio);
		Collections.sort(viaggi, new Functions(viaggio, viaggi));
		for (Viaggio i : viaggi) {
			System.out.println(i.getDistanza());
		}
        model.addAttribute("coordinateOrdered", viaggio);
		
		return "index";
	}
	
	@PostMapping("/viaggio_register")
	public String viaggioregister(Viaggio viaggio) {
		Date creationDate = new Date();
		viaggio.setcreationDate(creationDate);
		
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		CustomUserDetails auth2 = (CustomUserDetails) auth.getPrincipal();
		Long userId = auth2.getId();
		viaggio.setUserId(userId);
		viaggio.setPostiPrenotati(0);
		viaggio.setDistanza(Functions.distance(viaggio.getPartenzaX(), viaggio.getPartenzaY(), viaggio.getDestinazioneX(), viaggio.getDestinazioneY()));
		//Imposto il prezzo totale del viaggio in base alla distanza, da stabilire bene il fattore
		viaggio.setPrezzo((viaggio.getDistanza()) / 100.0);
		viaggioRepo.save(viaggio);
		System.out.println("id = " + userId);
		System.out.println("date = " + creationDate);
		return "redirect:/";
	}
	
	@PostMapping("/viaggio_prenota")
	public String viaggioprenota(Prenota prenota) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		CustomUserDetails auth2 = (CustomUserDetails) auth.getPrincipal();
		Long userId = auth2.getId();
		
		//Il viaggio che si vuole prenotare esiste?
		Viaggio check = viaggioRepo.findByviaggioId(prenota.getViaggioId());
		
		if (check != null) {
			//La prenotazione inserita è su un viaggio creato dall'utente?
			if (userId != check.getUserId() ) {
				//La prenotazione esiste già?
				List<Prenota> prenotazioni = prenotaRepo.findAll();
				boolean exist = false;
				for (Prenota i : prenotazioni) {
					System.out.println("1 ciclo ");
					if (i.getUserId() == prenota.getUserId() && i.getViaggioId() == prenota.getViaggioId() ) {
						exist = true;
					}
				}
				//Controllo anche se il viaggio ha ancora posti liberi prenotabili
				if ((!exist) && (check.getPostiPrenotati() >= check.getPostiTotali())) {
					check.setPostiPrenotati(check.getPostiPrenotati() + 1);
					prenotaRepo.save(prenota);
					System.out.println("Viaggio prenotato: " + prenota.getViaggioId());
				} else {
					System.out.println("Esiste già questa prenotazione. Posti totali: " + check.getPostiTotali() + " Posti prenotati: " + check.getPostiPrenotati());  
				}
			}
			else {
				System.out.println("Non puoi prenotare il tuo stesso viaggio ");
			}
		} else {
			System.out.println("Il viaggio prenotato non esiste ");
		}
		//viaggioRepo.insertPrenotazione(userId, prenota.getViaggioId());
	    return "redirect:/";
	}
	
	@PostMapping("/viaggio_delete")
	public String viaggiodelete(long viaggioId) {
		viaggioRepo.deleteById(viaggioId);
		return "redirect:/";
	}
	

	
	//Tutto ciò che segue non serve a niente, erano esperimenti	
	/*
	@GetMapping("/")
	public String variable(Model model) {
		Account account = new Account();
		String test = account.getName();
		model.addAttribute("account", account);
		model.addAttribute("test", test);
		return "index";
	}
	
	@GetMapping("/login.html")
    public String internal(Model model) {
        return "login";
    }
	
	@GetMapping("/index.html")
	public String index() {
		return "index";
	}
	
	@GetMapping("/users")
	public String listUsers( Model model) {
	    List<User> listUsers = userRepo.findAll();
	    model.addAttribute("listUsers", listUsers);
	     
	    return "users";
	}
	
	*/
}
