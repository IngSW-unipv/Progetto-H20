package thymeleaf;
import java.io.Serializable;

//Al momento inutile
public class Account implements Serializable {
    private Integer id = 42;
    private String name = "account di test";
    
	public Account() {
	}
	
	public String getName() {
		return name;
	}
	public Integer getId() {
		return id;
	}
}
