package thymeleaf;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

//Al momento inutile
@Controller
public class TLuserindex {

	@RequestMapping("/user/index")
	public String userIndex() {
		return "user/index";
	}

}
